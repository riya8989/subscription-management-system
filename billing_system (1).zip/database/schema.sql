-- ============================================================
-- LedgerFlow Subscription Billing System
-- MySQL Database Schema
-- ============================================================

CREATE DATABASE IF NOT EXISTS billing_system CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE billing_system;

-- ------------------------------------------------------------
-- 1. ADMINS (people who log into the dashboard)
-- ------------------------------------------------------------
CREATE TABLE admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ------------------------------------------------------------
-- 2. CUSTOMERS (the paying subscribers)
-- ------------------------------------------------------------
CREATE TABLE customers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(150) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    phone VARCHAR(20),
    company_name VARCHAR(150),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ------------------------------------------------------------
-- 3. PLANS (subscription tiers, e.g. Basic / Professional / Business)
-- ------------------------------------------------------------
CREATE TABLE plans (
    id INT AUTO_INCREMENT PRIMARY KEY,
    plan_name VARCHAR(100) NOT NULL,
    description VARCHAR(255),
    price DECIMAL(10,2) NOT NULL,
    billing_interval ENUM('monthly','yearly') NOT NULL DEFAULT 'monthly',
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ------------------------------------------------------------
-- 4. SUBSCRIPTIONS (link between a customer and a plan)
-- ------------------------------------------------------------
CREATE TABLE subscriptions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT NOT NULL,
    plan_id INT NOT NULL,
    status ENUM('trial','active','past_due','paused','cancelled') NOT NULL DEFAULT 'trial',
    start_date DATE NOT NULL,
    next_billing_date DATE NOT NULL,
    cancelled_at DATE DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE,
    FOREIGN KEY (plan_id) REFERENCES plans(id)
);

-- ------------------------------------------------------------
-- 5. INVOICES (generated per billing cycle)
-- ------------------------------------------------------------
CREATE TABLE invoices (
    id INT AUTO_INCREMENT PRIMARY KEY,
    invoice_number VARCHAR(30) NOT NULL UNIQUE,
    subscription_id INT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    status ENUM('unpaid','paid','overdue','refunded') NOT NULL DEFAULT 'unpaid',
    issued_date DATE NOT NULL,
    due_date DATE NOT NULL,
    paid_date DATE DEFAULT NULL,
    FOREIGN KEY (subscription_id) REFERENCES subscriptions(id) ON DELETE CASCADE
);

-- ------------------------------------------------------------
-- 6. PAYMENTS (actual transactions against an invoice)
-- ------------------------------------------------------------
CREATE TABLE payments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    invoice_id INT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    payment_method VARCHAR(50) DEFAULT 'manual',
    transaction_ref VARCHAR(100),
    paid_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (invoice_id) REFERENCES invoices(id) ON DELETE CASCADE
);

-- ------------------------------------------------------------
-- Sample data so the dashboard is not empty on first run
-- ------------------------------------------------------------
INSERT INTO admins (name, email, password_hash) VALUES
('Admin User', 'admin@ledgerflow.test', '$2y$10$92IXUNpkjO0rOQ5byMi.YeIVFF2K1KpJ8xYWNjPUwvKUpu7ORjHwm'); -- password: admin123

INSERT INTO plans (plan_name, description, price, billing_interval) VALUES
('Basic', '1 workspace, 5 members, email support', 499.00, 'monthly'),
('Professional', '5 workspaces, unlimited members, priority support', 1499.00, 'monthly'),
('Business', 'Unlimited workspaces, SSO, dedicated manager', 3999.00, 'monthly');

INSERT INTO customers (full_name, email, phone, company_name) VALUES
('Rohit Malhotra', 'rohit.m@nimbustech.in', '9876543210', 'Nimbus Tech'),
('Priya Deshmukh', 'priya@brightloop.co', '9823456712', 'BrightLoop'),
('Arjun Sethi', 'arjun.sethi@vector.dev', '9812345678', 'Vector Dev');

INSERT INTO subscriptions (customer_id, plan_id, status, start_date, next_billing_date) VALUES
(1, 2, 'active', '2026-08-14', '2026-09-14'),
(2, 3, 'active', '2026-08-19', '2026-09-19'),
(3, 1, 'past_due', '2026-08-02', '2026-09-02');

INSERT INTO invoices (invoice_number, subscription_id, amount, status, issued_date, due_date, paid_date) VALUES
('INV-10482', 1, 1499.00, 'paid', '2026-09-07', '2026-09-14', '2026-09-07'),
('INV-10481', 2, 3999.00, 'paid', '2026-09-06', '2026-09-19', '2026-09-06'),
('INV-10480', 3, 499.00, 'unpaid', '2026-09-02', '2026-09-09', NULL);
