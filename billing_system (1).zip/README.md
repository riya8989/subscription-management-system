# LedgerFlow — Subscription Billing System

PHP + MySQL + HTML5 + Pure CSS subscription billing dashboard.

## Setup (XAMPP / WAMP / any LAMP stack)

1. Copy the `billing_system` folder into your server's web root
   (e.g. `htdocs/billing_system` for XAMPP).

2. Create the database:
   - Open phpMyAdmin (or the MySQL CLI).
   - Import `database/schema.sql`. This creates the `billing_system`
     database, all tables, and some sample data.

3. Set your DB credentials in `config/db.php`:
   ```php
   $DB_HOST = 'localhost';
   $DB_NAME = 'billing_system';
   $DB_USER = 'root';
   $DB_PASS = '';
   ```

4. Open in browser:
   `http://localhost/billing_system/auth/login.php`

   Default login (from the sample data):
   - Email: `admin@ledgerflow.test`
   - Password: `admin123`

## Folder structure

```
billing_system/
├── admin/          Dashboard, plans, subscribers, invoices (protected pages)
├── auth/           Login / logout
├── config/         Database connection
├── includes/       Shared header/footer + session guard
├── assets/css/     Pure CSS stylesheet
├── cron/           Daily script to auto-generate invoices
└── database/       schema.sql — run this first
```

## Automatic billing

Set up a daily cron job to auto-generate invoices for subscriptions
due that day, and to flag overdue payments:

```
0 1 * * * /usr/bin/php /path/to/billing_system/cron/generate_invoices.php
```

## Security notes already built in

- Passwords are stored with `password_hash()` / verified with `password_verify()` — never in plain text.
- All SQL queries use PDO **prepared statements** — protected against SQL injection.
- Session ID is regenerated on login — protected against session fixation.
- All dynamic output is passed through `htmlspecialchars()` — protected against XSS.

## Next steps you may want to add

- Payment gateway integration (Razorpay / Stripe) instead of manual "mark as paid"
- Email notifications (PHPMailer) for invoices and payment reminders
- Edit/delete actions for plans and customers (currently create + view are wired up)
- Role-based access if more than one admin will use the panel
